const express = require('express')
const mongo = require('mongodb')
const cors = require('cors')

var app = express();
var mongoclient = mongo.MongoClient;
var objectid = mongo.ObjectID;
app.use(cors());
app.use(express.json());
app.use(express.urlencoded());

var database = "pizzeria";
app.get('/pizza',(req,res)=>{
    mongoclient.connect("mongodb://localhost:27017",(err,resp)=>{
        if(err)
            console.log(err)
        else{
            const db = resp.db(database);
            db.collection('pizza').find({}).toArray((err,output)=>{
                if(err)
                    console.log(err)
                else
                    res.send(output)
            })
        }
    })
})

app.get('/topping',(req,res)=>{
    mongoclient.connect("mongodb://localhost:27017",(err,resp)=>{
        if(err)
            console.log(err)
        else{
            const db = resp.db(database);
            db.collection('topping').find({}).toArray((err,output)=>{
                if(err)
                    console.log(err)
                else
                    res.send(output)
            })
        }
    })
})

app.get('/login',(req,res)=>{
    mongoclient.connect("mongodb://localhost:27017",(err,resp)=>{
        if(err)
            console.log(err)
        else{
            const db = resp.db(database);
            db.collection('users').find({}).toArray((err,output)=>{
                if(err)
                    console.log(err)
                else
                    res.send(output)
                    
            })
        }
    })
})

app.post('/addtocart',(req,response)=>{
    mongoclient.connect("mongodb://localhost:27017",(err,resp)=>{
        if(err)
            console.log(err)
        else{
            const db = resp.db(database);
            var data = {'uname':req.body.uname,'name':req.body.name,'price':req.body.price,'toppings':'BasePizza'}
            db.collection('cart').insertOne(data, function(err, res) {
                if (err)
                    console.log("Failed to add Pizza");
                else
                    console.log("Pizza Added Successfully");
            })
        }
    })
})

app.get('/viewcart/:uname',(req,res)=>{
    mongoclient.connect("mongodb://localhost:27017",(err,resp)=>{
        if(err)
            console.log(err)
        else{
            const db = resp.db(database);
            db.collection('cart').find({'uname':req.params.uname}).toArray((err,output)=>{
                if(err)
                    console.log(err)
                else
                    res.send(output)
                    
            })
        }
    })
})

app.put('/updatecart',(req,response)=>{
    mongoclient.connect("mongodb://localhost:27017",(err,resp)=>{
        if(err)
            console.log(err)
        else{
            const db = resp.db(database);
            var id = req.body.id;
            var updatequery = {_id:objectid(id)}
            var data = {$set:{price:req.body.price,toppings:req.body.toppings}};
            db.collection('cart').updateOne(updatequery,data, function(err, res) {
                if (err)
                    console.log("Failed to update");
                else
                    console.log("Updated Successfully");
            })
        }
    })
})

app.post('/deletecart',(req,response)=>{
    mongoclient.connect("mongodb://localhost:27017",(err,resp)=>{
        if(err)
            console.log(err)
        else{
            const db = resp.db(database);
            var id = req.body.id;
            var deletequery = {_id:objectid(id)}
            db.collection('cart').deleteOne(deletequery, function(err, res) {
                if (err)
                    console.log("Failed to remove");
                else
                    console.log("Removed Successfully");
            })
        }
    })
})

app.listen(3000,()=>{
    console.log("Server Running @ 3000")
})