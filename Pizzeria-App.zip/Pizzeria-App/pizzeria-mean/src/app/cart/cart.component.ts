import { Component, OnInit } from '@angular/core';
import { GetCartService } from '../get-cart.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  pizza;
  total:number = 0;
  pizzalist = [];
  constructor(private cart:GetCartService,private router:Router) { }

  ngOnInit(): void {
    var uname = sessionStorage.getItem('uname');
    this.cart.getCart(uname).subscribe((data)=>{
      this.pizza = data;
      for(let p of this.pizza){
        this.total += Number(p.price);
        this.pizzalist.push(p.name);
      }
    }) 
  }

  buildUrPizza(price,id,toppings){
    sessionStorage.setItem('price',price);
    sessionStorage.setItem('id',id);
    sessionStorage.setItem('toppings',toppings);
    this.router.navigate(['/topping'])
  }
  removePizza(id){
    var data = {'id':id};
    this.cart.deleteCart(data).subscribe(()=>{
     
    });
    alert("Pizza Removed");
    this.total = 0;
    this.ngOnInit(); 
  }
  checkOut(){
    alert("Thanks for Ordering. Please find details below:\nCustomer Name: "+sessionStorage.getItem('uname')
    +"\nPizza: "+this.pizzalist+"\nAmount: ₹"+this.total)
    this.router.navigate(['/home'])
  }

}
