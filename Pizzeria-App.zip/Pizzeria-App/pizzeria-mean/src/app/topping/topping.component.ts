import { Component, OnInit } from '@angular/core';
import { GetCartService } from '../get-cart.service';
import { GetToppingService } from '../get-topping.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-topping',
  templateUrl: './topping.component.html',
  styleUrls: ['./topping.component.css']
})
export class ToppingComponent implements OnInit {

  topping;
  total:number = Number(sessionStorage.getItem('price'));
  addedToppings = Array(sessionStorage.getItem('toppings'));
  constructor(private toppingservice:GetToppingService,private cart:GetCartService,private router:Router) { }

  ngOnInit(): void {
    this.toppingservice.getTopping().subscribe((data)=>{
      this.topping = data;
    })
  }

  updateTotal(name,cost,event){
    if(event.target.checked){
      this.total += Number(cost);
      this.addedToppings.push(name);
    }
    else{
      this.total -= Number(cost);
      const index = this.addedToppings.indexOf(name);
      this.addedToppings.splice(index, 1);
    }
  }

  updateCart(){
    //var data = {'uname':sessionStorage.getItem('uname'),'name':sessionStorage.getItem('name'),'id':sessionStorage.getItem('id'),'price':this.total};
    var data = {'id':sessionStorage.getItem('id'),'price':this.total,'toppings':this.addedToppings};
    console.log(data);
    this.cart.updateCart(data).subscribe(()=>{
     
    });
    alert("Cart Updated");
    //sessionStorage.setItem('price',this.total.toString());
    this.router.navigate(['/cart']);
  }

}
