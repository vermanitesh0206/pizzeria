import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GetPizzaService {

  constructor(private httpclient:HttpClient) { }

  getPizza(){
    return this.httpclient.get('http://localhost:3000/pizza');
  }
}
