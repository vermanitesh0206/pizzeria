import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GetUserService } from '../get-user.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user;
  constructor(private router: Router,private userservice:GetUserService) {}

  ngOnInit(): void {
    this.userservice.getUser().subscribe((data)=>{
      this.user = data;
    })
  }
  validateUser(name,password){
    var found = false;
    for(var u of this.user){
      if(u.name==name && u.password==password){
          found = true;
          sessionStorage.setItem('uname',name);
          this.router.navigate(['/home']);
      } 
    }
    if(!found){
      alert("Invalid Username/Password");
    }
  }
}
