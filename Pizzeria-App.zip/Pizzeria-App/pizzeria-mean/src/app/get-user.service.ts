import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GetUserService {

  constructor(private httpclient:HttpClient) { }

  getUser(){
    return this.httpclient.get('http://localhost:3000/login');
  }
}
