import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { GetPizzaService } from './get-pizza.service';

describe('GetPizzaService', () => {
  let service: GetPizzaService;
    
  beforeEach(() => {
    TestBed.configureTestingModule({
        imports: [HttpClientTestingModule], 
        providers: [GetPizzaService]
    });
    service = TestBed.inject(GetPizzaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('retrieves all the pizza', ()=>{
    service.getPizza().subscribe((result) => {
        console.log(result)
        expect(result).toBe(null);
    });
    
  });

});
