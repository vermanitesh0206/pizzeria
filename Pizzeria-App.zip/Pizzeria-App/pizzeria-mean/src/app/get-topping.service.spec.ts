import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { GetToppingService } from './get-topping.service';

describe('GetToppingService', () => {
  let service: GetToppingService;

  beforeEach(() => {
    TestBed.configureTestingModule({
        imports: [HttpClientTestingModule], 
        providers: [GetToppingService]
    });
    service = TestBed.inject(GetToppingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
