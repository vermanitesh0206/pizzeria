import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GetCartService {

  constructor(private httpclient:HttpClient) { }

  addPizza(data){
     return this.httpclient.post('http://localhost:3000/addtocart',data);
  }

  getCart(uname){
    return this.httpclient.get('http://localhost:3000/viewcart/'+uname);
  }

  updateCart(data){
    return this.httpclient.put('http://localhost:3000/updatecart',data);
 }

  deleteCart(data){
  return this.httpclient.post('http://localhost:3000/deletecart',data);
  }
}

