import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GetToppingService {

  constructor(private httpclient:HttpClient) { }

  getTopping(){
    return this.httpclient.get('http://localhost:3000/topping')
  }
}
