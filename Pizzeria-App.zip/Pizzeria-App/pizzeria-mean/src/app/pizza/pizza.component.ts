import { Component, OnInit } from '@angular/core';
import { GetPizzaService } from '../get-pizza.service';
import { Router } from '@angular/router';
import { GetCartService } from '../get-cart.service';
@Component({
  selector: 'app-pizza',
  templateUrl: './pizza.component.html',
  styleUrls: ['./pizza.component.css']
})
export class PizzaComponent implements OnInit {

  pizza;
  constructor(private router: Router,private pizzaservice:GetPizzaService,private cart:GetCartService) { }

  ngOnInit(): void {
    this.pizzaservice.getPizza().subscribe((data)=>{
      this.pizza = data;
    })
  }

  addPizza(name,price){
    var uname = sessionStorage.getItem('uname');
    var data = {'uname':uname,'name':name,'price':Number(price)};
    this.cart.addPizza(data).subscribe(()=>{
     
    });
    alert("Pizza Added");
    this.router.navigate(['/cart']);
  }

}
